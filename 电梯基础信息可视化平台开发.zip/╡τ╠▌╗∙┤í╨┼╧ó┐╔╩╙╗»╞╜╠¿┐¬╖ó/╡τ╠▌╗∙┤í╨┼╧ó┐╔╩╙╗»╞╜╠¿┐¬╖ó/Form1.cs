﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 电梯基础信息可视化平台开发
{


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(ThreadProc));
            t.ApartmentState = System.Threading.ApartmentState.STA;
            t.Start();
            this.Close();
        }

        public static void ThreadProc()
        {
            Application.Run(new Form2());//mainForm是要打开的窗口            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();//对Form2实例化
            this.Hide();//对用户隐藏控件Form1
            form3.ShowDialog();//将Form2显示为模式对话框
            this.Dispose();//将Form1释放掉
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();//对Form2实例化
            this.Hide();//对用户隐藏控件Form1
            form4.ShowDialog();//将Form2显示为模式对话框
            this.Dispose();//将Form1释放掉
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();//对Form2实例化
            this.Hide();//对用户隐藏控件Form1
            form5.ShowDialog();//将Form2显示为模式对话框
            this.Dispose();//将Form1释放掉
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string admin1="User1";
            string mima1 = "123456";
            string admin2 = "User2";
            string mima2 = "123456";
            if (admin1 == textBox1.Text)
            {
                if (mima1 == textBox2.Text)
                {
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    button4.Enabled = true;
                    quanxian.qx = 1;
                }
                else
                {
                    MessageBox.Show("密码错误");

                }
            }

            if (admin2 == textBox1.Text)
            {
                if (mima2 == textBox2.Text)
                {
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    button4.Enabled = false;
                    quanxian.qx = 2;
                }
                else
                {
                    MessageBox.Show("密码错误");
  
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (quanxian.qx==1)
            {
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
            }
            else if (quanxian.qx==2)
            {
                button1.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = false;
            }
        }
    }
    public class quanxian
    {
        public static int qx;
    }
}
