﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace 电梯基础信息可视化平台开发
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public static readonly Form2 getinstance = new Form2();

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection();
            SqlConnection conn = connection();
            string strcomm = "INSERT INTO elevator_information (所属项目) VALUES (NULL)";
            //update FilTer set 列名 = value where id = 3
            conn.Open();
            SqlCommand comm = new SqlCommand(strcomm, conn);
            comm.ExecuteNonQuery();
            GetDataGridView();
        }//添加

        private void button3_Click(object sender, EventArgs e)
        {
            System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(ThreadProc));
            t.ApartmentState = System.Threading.ApartmentState.STA;
            t.Start();
            this.Close();
        }//返回主界面
        public static void ThreadProc()
        {
            Application.Run(new Form1());//mainForm是要打开的窗口            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string str_con = @"Data Source=SKY-20180206HNX;Initial Catalog=elevator;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(str_con);
            //打开数据库连接
            conn.Open();
            string strQuery = "select * from elevator_information";
            SqlDataAdapter thisAdapter = new SqlDataAdapter(strQuery, str_con);
            SqlCommandBuilder thisBuilder = new SqlCommandBuilder(thisAdapter);
            DataSet ds = new DataSet();
            thisAdapter.Fill(ds, "elevator_information");
            thisAdapter.Update(ds, "elevator_information");
            thisAdapter.AcceptChangesDuringUpdate=(true);

        }//显示所有信息

        //用于适时修改数据
        private SqlConnection connection()
        {
            string strconn = "Data Source=SKY-20180206HNX;Initial Catalog=elevator;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(strconn);
            return conn;
        }

        private void GetDataGridView()
        {
            try
            {
                string strda = "select * from elevator_information";
                SqlConnection conn = connection();
                conn.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(strda, conn);
                da.Fill(ds, "显示数据");
                conn.Close();
                dataGridView1.AutoGenerateColumns = true;//自动创建列
                dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;//单击单元格编辑
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            connection();
            GetDataGridView();
        }//显示所有信息

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            SqlConnection conn = connection();
            try
            {
                string strcolumn = dataGridView1.Columns[e.ColumnIndex].HeaderText;//获取列标题
                string strrow = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();//获取焦点触发行的第一个值
                string value = dataGridView1.CurrentCell.Value.ToString();//获取当前点击的活动单元格的值
                string strcomm = "update elevator_information set " + strcolumn + "='" + value + "'where id = " + strrow;
                //update FilTer set 列名 = value where id = 3
                conn.Open();
                SqlCommand comm = new SqlCommand(strcomm, conn);
                comm.ExecuteNonQuery();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message.ToString());
            }
            finally
            {
                conn.Close();
            }
        }//修改信息

        private void button2_Click_1(object sender, EventArgs e)
        {

            string str_con = @"Data Source=SKY-20180206HNX;Initial Catalog=elevator;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(str_con);
            //打开数据库连接 
            conn.Open();
            //插入一条新数据
            string xunluo = textBox1.Text;
            string sql = "select * from elevator_information where (巡逻点卡号) = '" + xunluo + "'";
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataAdapter da = new SqlDataAdapter(comm);
            DataSet ds = new DataSet();
            da.Fill(ds, "elevator_information");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "elevator_information";
            conn.Close();
        }//精准查找

        private void button5_Click(object sender, EventArgs e)
        {
            string str_con = @"Data Source=SKY-20180206HNX;Initial Catalog=elevator;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(str_con);
            //打开数据库连接 
            conn.Open();
            //插入一条新数据
            string xunluo = textBox1.Text;
            string sql = "delete from elevator_information where (巡逻点卡号) = '" + xunluo + "'";
            SqlCommand comm = new SqlCommand(sql, conn);
            SqlDataAdapter da = new SqlDataAdapter(comm);
            DataSet ds = new DataSet();
            da.Fill(ds, "elevator_information");
            dataGridView1.DataSource = ds;
            GetDataGridView();
            conn.Close();
        }//删除
    }
}
