﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using System.Net;
using System.IO;
using System.Security.Permissions;  //交互JS

namespace 电梯基础信息可视化平台开发
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();//对Form2实例化
            this.Hide();//对用户隐藏控件Form1
            form1.ShowDialog();//将Form2显示为模式对话框
            this.Dispose();//将Form1释放掉
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            string url = Application.StartupPath + "\\m.html";
            //导航显示本地HTML文件
            webBrowser1.Navigate(url);
            webBrowser1.ObjectForScripting = this;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string strconn = "Data Source=SKY-20180206HNX;Initial Catalog=elevator;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            string s = "select 经度,纬度,电梯位置信息,状态 from elevator_extended_information";
            SqlDataAdapter da = new SqlDataAdapter(s, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                string jingdu = dt.Rows[i]["经度"].ToString();
                string weidu = dt.Rows[i]["纬度"].ToString();
                string dizhi = dt.Rows[i]["电梯位置信息"].ToString();
                string zhuangtai = dt.Rows[i]["状态"].ToString();
                double a = Convert.ToDouble(jingdu);
                double b = Convert.ToDouble(weidu);
                string c = Convert.ToString(dizhi);
                int d= Convert.ToInt16(zhuangtai);
                object[] objects = new object[4];
                objects[0] = a;
                objects[1] = b;
                objects[2] = c;
                objects[3] = d;
                webBrowser1.Document.InvokeScript("setLocation", objects);
            }
            //输入位置信息 得到经度纬度 显示对应低点的信息
            conn.Close();
        }
    }
}
